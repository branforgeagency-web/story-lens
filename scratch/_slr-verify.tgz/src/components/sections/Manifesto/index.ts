export { Manifesto } from "./Manifesto";
